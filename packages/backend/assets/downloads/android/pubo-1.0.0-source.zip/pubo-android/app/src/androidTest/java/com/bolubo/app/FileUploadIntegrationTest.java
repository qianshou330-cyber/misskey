package com.bolubo.app;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.webkit.WebView;
import androidx.core.content.FileProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.File;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;
import static org.junit.Assume.assumeTrue;

/** Selects a content URI through the actual WebView file-input callback, then reads it in JS. */
@RunWith(AndroidJUnit4.class)
public class FileUploadIntegrationTest {
    private final Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
    @Test public void selectedContentUriIsReadableWithoutGeneralContentAccess() throws Exception {
        assumeTrue(WebEnginePolicy.isSupported(WebView.getCurrentWebViewPackage().versionName));
        MainActivity activity = (MainActivity) instrumentation.startActivitySync(new Intent(instrumentation.getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        File directory = new File(activity.getCacheDir(), "camera");
        directory.mkdirs();
        File source = File.createTempFile("synthetic-upload-", ".bin", directory);
        Files.write(source.toPath(), "PUBO isolated upload fixture".getBytes(StandardCharsets.UTF_8));
        Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".files", source);
        IntentFilter filter = new IntentFilter(Intent.ACTION_OPEN_DOCUMENT);
        filter.addCategory(Intent.CATEGORY_OPENABLE);
        filter.addDataType("*/*");
        Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(filter, new Instrumentation.ActivityResult(Activity.RESULT_OK, new Intent().setData(uri)), true);
        try {
            Field field = MainActivity.class.getDeclaredField("webView"); field.setAccessible(true);
            WebView web = (WebView) field.get(activity);
            instrumentation.runOnMainSync(() -> {
                TrustedFixture.load(web, "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'></head><body><input id='file' type='file' accept='application/octet-stream' style='position:absolute;left:20px;top:20px;width:220px;height:100px'><script>window.qa='ready';file.onchange=async()=>{try{window.qa=await file.files[0].text()}catch(e){window.qa='error'}}</script></body></html>");
            });
            awaitValue(web, "window.qa", "\"ready\"");
            float[] point = new float[2];
            instrumentation.runOnMainSync(() -> {
                float density = activity.getResources().getDisplayMetrics().density;
                point[0] = 100 * density;
                point[1] = 60 * density;
            });
            long down = SystemClock.uptimeMillis();
            MotionEvent press = MotionEvent.obtain(down, down, MotionEvent.ACTION_DOWN, point[0], point[1], 0);
            MotionEvent release = MotionEvent.obtain(down, down + 80, MotionEvent.ACTION_UP, point[0], point[1], 0);
            press.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            release.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            // Route genuine touchscreen events through WebView without depending on
            // emulator SystemUI focus. Physical touch/window routing is separate QA.
            instrumentation.runOnMainSync(() -> {
                assertTrue(web.dispatchTouchEvent(press));
                assertTrue(web.dispatchTouchEvent(release));
            });
            press.recycle();
            release.recycle();
            awaitValue(web, "window.qa", "\"PUBO isolated upload fixture\"");
            assertEquals(1, monitor.getHits());
        } finally {
            instrumentation.removeMonitor(monitor);
            instrumentation.runOnMainSync(activity::finish);
            source.delete();
        }
    }
    private String evaluate(WebView view, String expression) throws Exception {
        CountDownLatch done = new CountDownLatch(1); String[] result = new String[1];
        instrumentation.runOnMainSync(() -> view.evaluateJavascript(expression, value -> { result[0] = value; done.countDown(); }));
        assertTrue(done.await(5, TimeUnit.SECONDS)); return result[0];
    }
    private void awaitValue(WebView view, String expression, String expected) throws Exception {
        long deadline = System.currentTimeMillis() + 25000; String value = null;
        while (System.currentTimeMillis() < deadline) { value = evaluate(view, expression); if (expected.equals(value)) return; Thread.sleep(100); }
        assertEquals(expected, value);
    }
}
