package com.bolubo.app;

import android.app.Instrumentation;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ApplicationSmokeTest {
    @Test public void launchesWithSecureSettingsAndGatesObsoleteEngine() throws Exception {
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        Intent launch = new Intent(instrumentation.getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        MainActivity activity = (MainActivity) instrumentation.startActivitySync(launch);
        try {
            instrumentation.waitForIdleSync();
            Field field = MainActivity.class.getDeclaredField("webView");
            field.setAccessible(true);
            WebView view = (WebView) field.get(activity);
            instrumentation.runOnMainSync(() -> {
                assertTrue(view.getSettings().getUserAgentString().contains("PUBOAndroid/1.0.0"));
                assertFalse(view.getSettings().getAllowFileAccess());
                assertFalse(view.getSettings().getAllowContentAccess());
                assertEquals(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW, view.getSettings().getMixedContentMode());
                assertTrue(view.getSettings().getMediaPlaybackRequiresUserGesture());
                PackageInfo provider = WebView.getCurrentWebViewPackage();
                if (provider == null || !WebEnginePolicy.isSupported(provider.versionName)) {
                    assertNull("Old engine must not navigate to the website", view.getUrl());
                    assertTrue(hasVisibleText(activity.getWindow().getDecorView(), "130 或以上"));
                } else assertTrue(OriginPolicy.isTrusted(view.getUrl()));
            });
        } finally { instrumentation.runOnMainSync(activity::finish); }
    }

    private boolean hasVisibleText(View view, String text) {
        if (view.getVisibility() != View.VISIBLE) return false;
        if (view instanceof TextView && ((TextView) view).getText().toString().contains(text)) return true;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int index = 0; index < group.getChildCount(); index++) if (hasVisibleText(group.getChildAt(index), text)) return true;
        }
        return false;
    }
}
