package com.bolubo.app;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.webkit.WebView;
import androidx.core.content.FileProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.File;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;
import static org.junit.Assume.assumeTrue;

/** Actual native bridge and content-provider IO with synthetic bytes, no real accounts. */
@RunWith(AndroidJUnit4.class)
public class PrivateDownloadIntegrationTest {
    private final Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();

    @Test public void acknowledgedChunksSaveExactBytesThroughContentProvider() throws Exception { transfer(false); }
    @Test public void cancelledTransferDoesNotPublishPartialBytes() throws Exception { transfer(true); }

    private void transfer(boolean cancel) throws Exception {
        assumeTrue(WebEnginePolicy.isSupported(WebView.getCurrentWebViewPackage().versionName));
        Intent launch = new Intent(instrumentation.getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        MainActivity activity = (MainActivity) instrumentation.startActivitySync(launch);
        File directory = new File(activity.getCacheDir(), "camera");
        directory.mkdirs();
        File destination = File.createTempFile("synthetic-save-", ".bin", directory);
        // FileProvider refuses DocumentsContract.deleteDocument. Seed a partial
        // destination to verify that cancellation also clears it via truncation.
        if (cancel) Files.write(destination.toPath(), new byte[] { 11, 22, 33 });
        Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".files", destination);
        IntentFilter filter = new IntentFilter(Intent.ACTION_CREATE_DOCUMENT);
        filter.addCategory(Intent.CATEGORY_OPENABLE);
        filter.addDataType("*/*");
        Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(filter,
            new Instrumentation.ActivityResult(Activity.RESULT_OK, new Intent().setData(uri)), true);
        try {
            Field field = MainActivity.class.getDeclaredField("webView"); field.setAccessible(true);
            WebView view = (WebView) field.get(activity);
            String script = "window.qa='loading';window.startSynthetic=function(){try{"
                + "let seq=0;const total=150000;const id='synthetic_" + (cancel ? "cancel" : "save") + "';"
                + "const send=x=>PuboNativeDownload.postMessage(JSON.stringify({v:1,id,...x}));"
                + "function chunk(){let start=seq*65536;if(start>=total){send({type:'finish'});return;}"
                + "let s='';for(let i=start;i<Math.min(start+65536,total);i++)s+=String.fromCharCode(i%251);"
                + "send({type:'chunk',seq,dataBase64:btoa(s)});}"
                + "PuboNativeDownload.onmessage=e=>{let r=JSON.parse(e.data);if(r.id!==id)return;"
                + "if(r.type==='ready')chunk();else if(r.type==='ack'){seq++;"
                + (cancel ? "send({type:'cancel'});" : "chunk();")
                + "}else if(['complete','cancelled','error'].includes(r.type))window.qa=r.type;};"
                + "send({type:'begin',name:'synthetic.bin',mime:'application/octet-stream',size:total});}catch(e){window.qa='exception:'+e.name+':'+e.message;}};window.qa='ready';";
            instrumentation.runOnMainSync(() -> {
                TrustedFixture.load(view, "<html><body><script>" + script + "</script></body></html>");
            });
            awaitValue(view, "window.qa", "\"ready\"");
            evaluate(view, "window.startSynthetic();'started'");
            try { awaitValue(view, "window.qa", cancel ? "\"cancelled\"" : "\"complete\""); }
            catch (AssertionError error) {
                String[] top = new String[1]; instrumentation.runOnMainSync(() -> top[0] = view.getUrl());
                Field downloadsField = MainActivity.class.getDeclaredField("downloads"); downloadsField.setAccessible(true);
                Object manager = downloadsField.get(activity);
                Field activeField = PrivateDownloadBridge.class.getDeclaredField("active"); activeField.setAccessible(true);
                fail("Synthetic bridge state: nativeTop=" + top[0] + ", chooserHits=" + monitor.getHits() + ", active=" + (activeField.get(manager) != null)
                    + ", JS=" + evaluate(view, "JSON.stringify({qa:window.qa,bridge:typeof PuboNativeDownload,url:location.href})"));
            }
            assertEquals("Save chooser was requested exactly once", 1, monitor.getHits());
            if (cancel) {
                long deadline = System.currentTimeMillis()+5000;
                while (destination.exists() && destination.length()!=0 && System.currentTimeMillis()<deadline) Thread.sleep(50);
                assertTrue(!destination.exists() || destination.length()==0);
            } else {
                byte[] actual = Files.readAllBytes(destination.toPath());
                assertEquals(150000, actual.length);
                for (int i=0;i<actual.length;i++) assertEquals((byte)(i%251),actual[i]);
            }
        } finally {
            instrumentation.removeMonitor(monitor);
            instrumentation.runOnMainSync(activity::finish);
            destination.delete();
        }
    }

    private String evaluate(WebView view, String expression) throws Exception {
        CountDownLatch done = new CountDownLatch(1); String[] result = new String[1];
        instrumentation.runOnMainSync(() -> view.evaluateJavascript(expression, value -> {result[0]=value;done.countDown();}));
        assertTrue(done.await(5,TimeUnit.SECONDS)); return result[0];
    }
    private void awaitValue(WebView view,String expression,String expected) throws Exception {
        long deadline=System.currentTimeMillis()+25000;String value=null;
        while(System.currentTimeMillis()<deadline){value=evaluate(view,expression);if(expected.equals(value))return;Thread.sleep(100);}
        assertEquals(expected,value);
    }
}
