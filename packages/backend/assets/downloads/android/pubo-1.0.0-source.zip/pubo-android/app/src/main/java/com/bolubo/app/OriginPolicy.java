package com.bolubo.app;

import java.net.URI;
import java.net.URISyntaxException;

/** One exact first-party origin. Subdomains, userinfo and alternate ports are not trusted. */
public final class OriginPolicy {
    public static final String HOME = "https://bolubo.com/";
    public static final String ORIGIN = "https://bolubo.com";
    private OriginPolicy() { }

    public static boolean isTrusted(String value) {
        if (value == null || value.length() > 16384) return false;
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme())
                && "bolubo.com".equalsIgnoreCase(uri.getHost())
                && uri.getRawUserInfo() == null
                && (uri.getPort() == -1 || uri.getPort() == 443);
        } catch (URISyntaxException e) { return false; }
    }

    public static boolean canOpenExternally(String value) {
        if (value == null || value.length() > 16384) return false;
        try {
            URI uri = new URI(value);
            String scheme = uri.getScheme();
            return ("https".equalsIgnoreCase(scheme) && uri.getHost() != null && uri.getRawUserInfo() == null)
                || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme);
        } catch (URISyntaxException e) { return false; }
    }

    public static boolean allowBridge(String sourceOrigin, boolean mainFrame, String topUrl) {
        return mainFrame && isTrusted(sourceOrigin) && isTrusted(topUrl);
    }
}
