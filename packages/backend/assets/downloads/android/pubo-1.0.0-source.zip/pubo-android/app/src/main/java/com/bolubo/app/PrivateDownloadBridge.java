package com.bolubo.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.webkit.WebView;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Receives only already-authorized bytes; never accepts URLs, cookies or tokens. */
public final class PrivateDownloadBridge {
    static final int CREATE_DOCUMENT = 8401;
    private final Activity activity;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Session active;
    private Session chooser;
    private boolean closed;

    private static final class Session {
        final DownloadState state;
        final JavaScriptReplyProxy reply;
        final long started = android.os.SystemClock.elapsedRealtime();
        volatile boolean cancelled;
        volatile boolean published;
        boolean pending;
        Uri destination;
        File file;
        FileOutputStream stream;
        Runnable timeout;
        Session(DownloadState state, JavaScriptReplyProxy reply) { this.state = state; this.reply = reply; }
    }

    public PrivateDownloadBridge(Activity activity) {
        this.activity = activity;
        // Only fully received bytes are copied to a public destination. Private
        // staging files from an interrupted process are cleared at the next startup.
        io.execute(() -> {
            File directory = new File(activity.getCacheDir(), "private-downloads");
            File[] files = directory.listFiles();
            if (files != null) for (File file : files) {
                if (file.isFile() && file.getName().startsWith("transfer-")) file.delete();
            }
        });
    }

    public boolean install(WebView webView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return false;
        WebViewCompat.addWebMessageListener(webView, "PuboNativeDownload", Collections.singleton(OriginPolicy.ORIGIN),
            (view, message, origin, mainFrame, reply) -> {
                if (closed || !OriginPolicy.allowBridge(origin.toString(), mainFrame, view.getUrl())) return;
                receive(message, reply);
            });
        return true;
    }

    private void receive(WebMessageCompat message, JavaScriptReplyProxy reply) {
        String data;
        try { data = message.getData(); } catch (IllegalStateException e) { return; }
        if (data == null || data.length() > DownloadState.MAX_MESSAGE) return;
        JSONObject json;
        String id = null;
        try {
            json = new JSONObject(data);
            if (!(json.opt("v") instanceof Integer) || json.getInt("v") != 1) throw new JSONException("version");
            id = strictString(json, "id");
            if (!DownloadState.validId(id)) throw new JSONException("id");
            String type = strictString(json, "type");
            if ("begin".equals(type)) { begin(json, id, reply); return; }
            Session session = active;
            if (session == null || !session.state.id.equals(id)) { respond(reply, "error", id, -1, "NO_TRANSFER"); return; }
            if ("cancel".equals(type)) { cancel("cancelled", null); return; }
            if (session.pending) { cancel("error", "BACKPRESSURE"); return; }
            if ("chunk".equals(type)) {
                Object sequence = json.opt("seq");
                if (!(sequence instanceof Integer) || ((Integer) sequence) < 0) throw new JSONException("seq");
                chunk(session, (Integer) sequence, strictString(json, "dataBase64"));
            } else if ("finish".equals(type)) { finish(session); }
            else { cancel("error", "INVALID_MESSAGE"); }
        } catch (JSONException | IllegalArgumentException e) {
            if (active != null && active.state.id.equals(id)) cancel("error", "INVALID_MESSAGE");
            else if (DownloadState.validId(id)) respond(reply, "error", id, -1, "INVALID_MESSAGE");
        }
    }

    private static String strictString(JSONObject json, String key) throws JSONException {
        Object value = json.get(key);
        if (!(value instanceof String)) throw new JSONException(key);
        return (String) value;
    }

    private void begin(JSONObject json, String id, JavaScriptReplyProxy reply) throws JSONException {
        if (active != null || chooser != null) { respond(reply, "error", id, -1, "BUSY"); return; }
        Object size = json.get("size");
        if (!(size instanceof Integer) && !(size instanceof Long)) throw new JSONException("size");
        DownloadState state = new DownloadState(id, strictString(json, "name"), strictString(json, "mime"), ((Number) size).longValue());
        Session session = new Session(state, reply);
        active = session;
        chooser = session;
        session.pending = true;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(state.mime).putExtra(Intent.EXTRA_TITLE, state.name);
        try {
            activity.startActivityForResult(intent, CREATE_DOCUMENT);
            timeout(session, 120000);
        } catch (RuntimeException e) {
            chooser = null;
            cancel("error", "SAVE_UNAVAILABLE");
        }
    }

    public void onActivityResult(int resultCode, Intent result) {
        Session session = chooser;
        chooser = null;
        Uri uri = resultCode == Activity.RESULT_OK && result != null ? result.getData() : null;
        if (session == null) return;
        if (uri == null || !"content".equals(uri.getScheme())) {
            if (session == active) cancel("cancelled", null);
            return;
        }
        session.destination = uri;
        if (session != active || session.cancelled || closed) { io.execute(() -> clean(session)); return; }
        timeout(session, 30000);
        io.execute(() -> {
            try {
                if (session.cancelled) { clean(session); return; }
                File directory = new File(activity.getCacheDir(), "private-downloads");
                if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("cache");
                session.file = File.createTempFile("transfer-", ".part", directory);
                session.stream = new FileOutputStream(session.file);
                session.state.ready();
                main.post(() -> {
                    if (session != active || session.cancelled) return;
                    session.pending = false;
                    respond(session.reply, "ready", session.state.id, -1, null);
                    timeout(session, 30000);
                });
            } catch (IOException | IllegalStateException e) { fail(session, "SAVE_FAILED"); }
        });
    }

    private void chunk(Session session, int seq, String data) {
        session.pending = true;
        io.execute(() -> {
            try {
                if (session.cancelled) return;
                byte[] bytes = session.state.accept(seq, data);
                session.stream.write(bytes);
                main.post(() -> {
                    if (session != active || session.cancelled) return;
                    session.pending = false;
                    respond(session.reply, "ack", session.state.id, seq, null);
                    timeout(session, 30000);
                });
            } catch (IOException | IllegalStateException | IllegalArgumentException | NullPointerException e) { fail(session, "INVALID_CHUNK"); }
        });
    }

    private void finish(Session session) {
        session.pending = true;
        timeout(session, 120000);
        io.execute(() -> {
            try {
                if (session.cancelled) return;
                session.state.finish();
                session.stream.close();
                session.stream = null;
                try (FileInputStream input = new FileInputStream(session.file);
                     OutputStream output = activity.getContentResolver().openOutputStream(session.destination, "wt")) {
                    if (output == null) throw new IOException("destination");
                    byte[] buffer = new byte[DownloadState.MAX_CHUNK];
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        if (session.cancelled) throw new IOException("cancelled");
                        output.write(buffer, 0, count);
                    }
                    output.flush();
                }
                main.post(() -> {
                    if (session != active || session.cancelled) return;
                    session.published = true;
                    main.removeCallbacks(session.timeout);
                    active = null;
                    respond(session.reply, "complete", session.state.id, -1, null);
                    io.execute(() -> clean(session));
                });
            } catch (IOException | IllegalStateException | NullPointerException e) { fail(session, "SAVE_FAILED"); }
        });
    }

    private void timeout(Session session, long delay) {
        if (session.timeout != null) main.removeCallbacks(session.timeout);
        long remaining = 600000 - (android.os.SystemClock.elapsedRealtime() - session.started);
        session.timeout = () -> { if (active == session) cancel("error", "TIMEOUT"); };
        main.postDelayed(session.timeout, Math.max(1, Math.min(delay, remaining)));
    }

    private void fail(Session session, String code) {
        main.post(() -> { if (session == active) cancel("error", code); });
    }

    public void cancelForNavigation() { cancel("cancelled", null); }

    private void cancel(String type, String code) {
        Session session = active;
        if (session == null) return;
        active = null;
        session.cancelled = true;
        if (session.timeout != null) main.removeCallbacks(session.timeout);
        respond(session.reply, type, session.state.id, -1, code);
        io.execute(() -> clean(session));
    }

    private void clean(Session session) {
        session.state.cancel();
        try { if (session.stream != null) session.stream.close(); } catch (IOException ignored) { }
        session.stream = null;
        if (session.file != null) session.file.delete();
        if (!session.published && session.destination != null) {
            // This URI is returned only by our user-confirmed ACTION_CREATE_DOCUMENT.
            // Clear unfinished bytes before deletion: non-document providers can
            // return a misleading successful result to DocumentsContract calls.
            boolean cleared = false;
            try (OutputStream output = activity.getContentResolver().openOutputStream(session.destination, "wt")) {
                cleared = output != null;
            } catch (Exception ignored) { /* Never log document URIs or private bytes. */ }
            boolean removed = false;
            try {
                if (DocumentsContract.isDocumentUri(activity, session.destination))
                    removed = DocumentsContract.deleteDocument(activity.getContentResolver(), session.destination);
                else removed = activity.getContentResolver().delete(session.destination, null, null) > 0;
            }
            catch (Exception ignored) { /* Some providers support writes but not deletion. */ }
            if (!cleared && !removed) main.post(() -> android.widget.Toast.makeText(activity.getApplicationContext(),
                "保存位置未能清理未完成的文件，请检查刚才选择的位置。", android.widget.Toast.LENGTH_LONG).show());
        }
    }

    private static void respond(JavaScriptReplyProxy reply, String type, String id, int seq, String code) {
        try {
            JSONObject object = new JSONObject().put("v", 1).put("type", type).put("id", id);
            if (seq >= 0) object.put("seq", seq);
            if (code != null) object.put("code", code);
            reply.postMessage(object.toString());
        } catch (JSONException | RuntimeException ignored) { /* The initiating document may have gone away. */ }
    }

    public void close() {
        cancel("cancelled", null);
        closed = true;
        io.shutdown();
    }
}
