package com.bolubo.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class OriginPolicyTest {
    @Test public void exactOriginIsTrustedAcrossRoutes() {
        assertTrue(OriginPolicy.isTrusted("https://bolubo.com/"));
        assertTrue(OriginPolicy.isTrusted("https://bolubo.com:443/chat/room?q=1#x"));
        assertTrue(OriginPolicy.isTrusted("https://BOLUBO.com/download/android"));
    }
    @Test public void rejectsOriginConfusionAndLocalSchemes() {
        String[] urls = {"http://bolubo.com", "https://bolubo.com:8443", "https://evil.bolubo.com", "https://bolubo.com.evil.test", "https://bolubo.com@evil.test", "https://evil@bolubo.com", "https://bolubo.com\\@evil.test", "file:///private/file", "content://private", "javascript:alert(1)", "intent://bolubo.com", "https://bolubo.com.", "https://bolubo.com%2e.evil.test", null};
        for (String url : urls) assertFalse(String.valueOf(url), OriginPolicy.isTrusted(url));
    }
    @Test public void rejectsIframeAndWrongTopLevelEvenWhenSourceLooksTrusted() {
        assertTrue(OriginPolicy.allowBridge("https://bolubo.com", true, "https://bolubo.com/chat"));
        assertFalse(OriginPolicy.allowBridge("https://bolubo.com", false, "https://bolubo.com/chat"));
        assertFalse(OriginPolicy.allowBridge("https://bolubo.com", true, "https://evil.test"));
        assertFalse(OriginPolicy.allowBridge("https://evil.test", true, "https://bolubo.com/chat"));
    }
    @Test public void externalNavigationOnlyUsesNarrowPublicSchemes() {
        assertTrue(OriginPolicy.canOpenExternally("https://example.com/video"));
        assertTrue(OriginPolicy.canOpenExternally("mailto:hello@example.com"));
        assertTrue(OriginPolicy.canOpenExternally("tel:+123"));
        for (String url : new String[] {"http://example.com", "javascript:alert(1)", "intent://evil", "file:///secret", "content://secret", "data:text/html,x", "https://user:secret@example.com"}) assertFalse(url, OriginPolicy.canOpenExternally(url));
    }
}
