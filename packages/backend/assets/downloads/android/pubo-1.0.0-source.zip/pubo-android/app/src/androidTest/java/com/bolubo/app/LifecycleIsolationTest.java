package com.bolubo.app;

import android.Manifest;
import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LifecycleIsolationTest {
    @Test public void latePickerCannotDeliverOldUriToNewDocument() throws Exception {
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        MainActivity activity = launch(instrumentation);
        try {
            WebView web = (WebView) get(activity, "webView");
            AtomicInteger oldCancelled = new AtomicInteger();
            AtomicInteger newRejected = new AtomicInteger();
            ValueCallback<Uri[]> oldCallback = uris -> { assertNull(uris); oldCancelled.incrementAndGet(); };
            instrumentation.runOnMainSync(() -> {
                set(activity, "fileCallback", oldCallback);
                set(activity, "chooserResultCallback", oldCallback);
                set(activity, "chooserActivityPending", true);
                web.getWebViewClient().onPageStarted(web, OriginPolicy.HOME, null);
                assertEquals(1, oldCancelled.get());
                web.getWebChromeClient().onShowFileChooser(web, uris -> { assertNull(uris); newRejected.incrementAndGet(); }, null);
                assertEquals(1, newRejected.get());
                activity.onActivityResult(8301, Activity.RESULT_OK, new Intent().setData(Uri.parse("content://test.invalid/previous-account")));
                assertEquals(1, oldCancelled.get());
                assertEquals(1, newRejected.get());
                assertNull(get(activity, "fileCallback"));
                assertEquals(false, get(activity, "chooserActivityPending"));
            });
        } finally { instrumentation.runOnMainSync(activity::finish); }
    }

    @Test public void staleMicrophonePermissionCannotGrantNewPageRequest() throws Exception {
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        MainActivity activity = launch(instrumentation);
        try {
            WebView web = (WebView) get(activity, "webView");
            RecordingPermission oldRequest = new RecordingPermission();
            RecordingPermission newRequest = new RecordingPermission();
            instrumentation.runOnMainSync(() -> {
                set(activity, "mediaRequest", oldRequest);
                set(activity, "mediaOsRequest", oldRequest);
                set(activity, "mediaPermissionPending", true);
                set(activity, "mediaResources", new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE });
                web.getWebViewClient().onPageStarted(web, OriginPolicy.HOME, null);
                web.getWebChromeClient().onPermissionRequest(newRequest);
                assertEquals(1, oldRequest.denied);
                assertEquals(1, newRequest.denied);
                activity.onRequestPermissionsResult(8303, new String[] { Manifest.permission.RECORD_AUDIO }, new int[] { PackageManager.PERMISSION_GRANTED });
                assertEquals(0, oldRequest.granted);
                assertEquals(0, newRequest.granted);
                assertEquals(false, get(activity, "mediaPermissionPending"));
            });
        } finally { instrumentation.runOnMainSync(activity::finish); }
    }

    private MainActivity launch(Instrumentation instrumentation) {
        return (MainActivity) instrumentation.startActivitySync(new Intent(instrumentation.getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    private static Object get(MainActivity activity, String name) {
        try { Field field = MainActivity.class.getDeclaredField(name); field.setAccessible(true); return field.get(activity); }
        catch (ReflectiveOperationException e) { throw new AssertionError(e); }
    }
    private static void set(MainActivity activity, String name, Object value) {
        try { Field field = MainActivity.class.getDeclaredField(name); field.setAccessible(true); field.set(activity, value); }
        catch (ReflectiveOperationException e) { throw new AssertionError(e); }
    }
    private static final class RecordingPermission extends PermissionRequest {
        int granted;
        int denied;
        @Override public Uri getOrigin() { return Uri.parse(OriginPolicy.ORIGIN); }
        @Override public String[] getResources() { return new String[] { RESOURCE_AUDIO_CAPTURE }; }
        @Override public void grant(String[] resources) { granted++; }
        @Override public void deny() { denied++; }
    }
}
