package com.bolubo.app;

import android.graphics.Bitmap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

/** Instrumentation-only HTTPS fixture: no server route or production trust policy is changed. */
final class TrustedFixture {
    static final String URL = OriginPolicy.ORIGIN + "/__android_instrumentation_fixture__";
    static void load(WebView view, String html) {
        WebViewClient original = view.getWebViewClient();
        view.stopLoading();
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView web, WebResourceRequest request) {
                if (URL.equals(request.getUrl().toString())) return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8)));
                return original.shouldInterceptRequest(web, request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView web, WebResourceRequest request) { return original.shouldOverrideUrlLoading(web, request); }
            @Override public void onPageStarted(WebView web, String url, Bitmap icon) { original.onPageStarted(web, url, icon); }
            @Override public void onPageFinished(WebView web, String url) { original.onPageFinished(web, url); }
        });
        view.loadUrl(URL);
    }
}
