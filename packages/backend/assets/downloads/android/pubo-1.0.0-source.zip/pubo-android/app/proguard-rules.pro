# The app uses AndroidX WebKit's origin-scoped message listener, not reflection or
# addJavascriptInterface. No broad keep rules are required.
