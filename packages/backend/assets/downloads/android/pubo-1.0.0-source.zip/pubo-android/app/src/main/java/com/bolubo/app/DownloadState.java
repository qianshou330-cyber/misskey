package com.bolubo.app;

import java.util.Base64;
import java.util.regex.Pattern;

/** Pure Java bounded transfer state. The caller serializes all operations. */
public final class DownloadState {
    public static final long MAX_SIZE = 50L * 1024 * 1024;
    public static final int MAX_CHUNK = 65536;
    public static final int MAX_MESSAGE = 90000;
    private static final Pattern ID = Pattern.compile("[A-Za-z0-9_-]{1,80}");
    private static final Pattern MIME = Pattern.compile("[A-Za-z0-9!#$&^_.+-]{1,100}/[A-Za-z0-9!#$&^_.+-]{1,100}");
    public final String id;
    public final long size;
    public final String name;
    public final String mime;
    private int nextSequence;
    private long received;
    private boolean ready;
    private boolean complete;
    private boolean cancelled;

    public DownloadState(String id, String name, String mime, long size) {
        if (!validId(id) || size < 0 || size > MAX_SIZE) throw new IllegalArgumentException("INVALID_BEGIN");
        this.id = id;
        this.size = size;
        this.name = safeName(name);
        this.mime = mime != null && MIME.matcher(mime).matches() ? mime : "application/octet-stream";
    }

    public static boolean validId(String id) { return id != null && ID.matcher(id).matches(); }

    public static String safeName(String name) {
        String safe = name == null ? "PUBO-file" : name.replaceAll("[\\\\/\\p{Cntrl}<>:\"|?*\\u202A-\\u202E\\u2066-\\u2069]", "_").trim();
        if (safe.isEmpty() || safe.equals(".") || safe.equals("..")) return "PUBO-file";
        return safe.length() > 180 ? safe.substring(0, 180) : safe;
    }

    public void ready() {
        if (cancelled || complete || ready) throw new IllegalStateException("INVALID_STATE");
        ready = true;
    }

    public byte[] accept(int sequence, String base64) {
        if (!ready || complete || cancelled || sequence != nextSequence) throw new IllegalStateException("INVALID_SEQUENCE");
        if (base64 == null || base64.isEmpty() || base64.length() > 87384) throw new IllegalArgumentException("INVALID_CHUNK");
        byte[] bytes;
        try { bytes = Base64.getDecoder().decode(base64); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("INVALID_CHUNK"); }
        if (bytes.length == 0 || bytes.length > MAX_CHUNK || received + bytes.length > size
            || !Base64.getEncoder().encodeToString(bytes).equals(base64)) throw new IllegalArgumentException("INVALID_CHUNK");
        received += bytes.length;
        nextSequence++;
        return bytes;
    }

    public void finish() {
        if (!ready || complete || cancelled || received != size) throw new IllegalStateException("INCOMPLETE");
        complete = true;
    }

    public void cancel() { cancelled = true; }
    public long received() { return received; }
}
