package com.bolubo.app;

import org.junit.Test;
import java.util.Base64;
import static org.junit.Assert.*;

public class DownloadStateTest {
    @Test public void transfersExactlyDeclaredBytesInOrder() {
        DownloadState state = new DownloadState("first-file", "example.txt", "text/plain", 3);
        state.ready();
        assertArrayEquals(new byte[] {1, 2}, state.accept(0, "AQI="));
        assertArrayEquals(new byte[] {3}, state.accept(1, "Aw=="));
        state.finish();
        assertEquals(3, state.received());
        assertThrows(IllegalStateException.class, () -> state.accept(2, "BA=="));
    }
    @Test public void rejectsOversizedAndNegativeMetadata() {
        assertThrows(IllegalArgumentException.class, () -> new DownloadState("id", "x", "text/plain", DownloadState.MAX_SIZE + 1));
        assertThrows(IllegalArgumentException.class, () -> new DownloadState("id", "x", "text/plain", -1));
        assertThrows(IllegalArgumentException.class, () -> new DownloadState("../bad", "x", "text/plain", 1));
    }
    @Test public void rejectsSkippedDuplicateAndPreReadyChunks() {
        DownloadState state = new DownloadState("id", "x", "text/plain", 3);
        assertThrows(IllegalStateException.class, () -> state.accept(0, "AQ=="));
        state.ready();
        assertThrows(IllegalStateException.class, () -> state.accept(1, "AQ=="));
        state.accept(0, "AQ==");
        assertThrows(IllegalStateException.class, () -> state.accept(0, "AQ=="));
    }
    @Test public void rejectsOverrunIncompleteAndInvalidBase64() {
        DownloadState state = new DownloadState("id", "x", "text/plain", 1);
        state.ready();
        assertThrows(IllegalStateException.class, state::finish);
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, "AQI="));
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, "AQ==\n"));
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, "AQ"));
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, "!!!!"));
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, ""));
    }
    @Test public void capsDecodedChunkAndSupportsExactlyFiftyMiB() {
        DownloadState state = new DownloadState("id", "x", "application/octet-stream", DownloadState.MAX_SIZE);
        state.ready();
        byte[] large = new byte[DownloadState.MAX_CHUNK + 1];
        assertThrows(IllegalArgumentException.class, () -> state.accept(0, Base64.getEncoder().encodeToString(large)));
        String valid = Base64.getEncoder().encodeToString(new byte[DownloadState.MAX_CHUNK]);
        for (int index = 0; index < DownloadState.MAX_SIZE / DownloadState.MAX_CHUNK; index++) state.accept(index, valid);
        state.finish();
    }
    @Test public void cancellationPreventsFurtherWrites() {
        DownloadState state = new DownloadState("id", "x", "text/plain", 1);
        state.ready();
        state.cancel();
        assertThrows(IllegalStateException.class, () -> state.accept(0, "AQ=="));
        assertThrows(IllegalStateException.class, state::finish);
    }
    @Test public void zeroLengthFileAndUntrustedMetadataAreHandled() {
        DownloadState state = new DownloadState("id", "../bad\nname\u202e.exe", "text/plain\r\nX-Test: 1", 0);
        assertEquals("application/octet-stream", state.mime);
        assertFalse(state.name.contains("/"));
        assertFalse(state.name.contains("\n"));
        assertFalse(state.name.contains("\u202e"));
        assertEquals("PUBO-file", DownloadState.safeName(".."));
        state.ready();
        state.finish();
    }
}
