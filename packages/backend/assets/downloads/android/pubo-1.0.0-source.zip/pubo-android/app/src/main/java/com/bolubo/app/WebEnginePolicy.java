package com.bolubo.app;

public final class WebEnginePolicy {
    // Matches the published website's Vite chrome130 build target.
    public static final int MINIMUM_MAJOR = 130;
    private WebEnginePolicy() { }
    public static boolean isSupported(String version) {
        if (version == null || !version.matches("[0-9]{1,5}(\\.[0-9]+){1,4}")) return false;
        try { return Integer.parseInt(version.substring(0, version.indexOf('.'))) >= MINIMUM_MAJOR; }
        catch (NumberFormatException e) { return false; }
    }
}
