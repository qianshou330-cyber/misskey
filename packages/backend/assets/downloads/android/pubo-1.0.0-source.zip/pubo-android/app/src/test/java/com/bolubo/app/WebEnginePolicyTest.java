package com.bolubo.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class WebEnginePolicyTest {
    @Test public void matchesWebsiteCompilationTarget() {
        assertTrue(WebEnginePolicy.isSupported("130.0.6723.58"));
        assertTrue(WebEnginePolicy.isSupported("133.0.6943.137"));
        assertFalse(WebEnginePolicy.isSupported("129.0.0.0"));
        assertFalse(WebEnginePolicy.isSupported("69.0.3497.100"));
        assertFalse(WebEnginePolicy.isSupported(null));
        assertFalse(WebEnginePolicy.isSupported("unknown"));
    }
}
