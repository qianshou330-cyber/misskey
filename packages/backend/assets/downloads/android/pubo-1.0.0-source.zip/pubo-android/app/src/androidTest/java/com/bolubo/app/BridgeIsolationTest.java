package com.bolubo.app;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.Collections;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.Assert.*;
import static org.junit.Assume.assumeTrue;

/** Exercises the real WebView origin/frame metadata with isolated synthetic pages. */
@RunWith(AndroidJUnit4.class)
public class BridgeIsolationTest {
    @Test public void listenerAcceptsTopFrameAndRejectsSameOriginChildFrame() throws Exception {
        assumeTrue(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER));
        AtomicInteger accepted = new AtomicInteger();
        AtomicInteger rejected = new AtomicInteger();
        CountDownLatch received = new CountDownLatch(2);
        WebView[] holder = new WebView[1];
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> {
            Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
            WebView view = new WebView(context);
            holder[0] = view;
            view.getSettings().setJavaScriptEnabled(true);
            WebViewCompat.addWebMessageListener(view, "Probe", Collections.singleton(OriginPolicy.ORIGIN), (web, message, origin, main, reply) -> {
                if (OriginPolicy.allowBridge(origin.toString(), main, OriginPolicy.HOME)) accepted.incrementAndGet(); else rejected.incrementAndGet();
                received.countDown();
            });
            view.loadDataWithBaseURL(OriginPolicy.HOME, "<script>Probe.postMessage('top')</script><iframe srcdoc=\"&lt;script&gt;Probe.postMessage('child')&lt;/script&gt;\"></iframe>", "text/html", "UTF-8", null);
        });
        try {
            assertTrue("Both frame callbacks arrived", received.await(15, TimeUnit.SECONDS));
            assertEquals(1, accepted.get());
            assertEquals(1, rejected.get());
        } finally { InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> holder[0].destroy()); }
    }

    @Test public void bridgeIsNotExposedToExternalOrigin() throws Exception {
        assumeTrue(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER));
        CountDownLatch result = new CountDownLatch(1);
        String[] evaluated = new String[1];
        WebView[] holder = new WebView[1];
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> {
            WebView view = new WebView(InstrumentationRegistry.getInstrumentation().getTargetContext());
            holder[0] = view;
            view.getSettings().setJavaScriptEnabled(true);
            WebViewCompat.addWebMessageListener(view, "Probe", Collections.singleton(OriginPolicy.ORIGIN), (web, message, origin, main, reply) -> fail("External origin called bridge"));
            view.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView web, String url) {
                    web.evaluateJavascript("typeof window.Probe", value -> { evaluated[0] = value; result.countDown(); });
                }
            });
            view.loadDataWithBaseURL("https://example.invalid/", "<p>external origin</p>", "text/html", "UTF-8", null);
        });
        try {
            assertTrue(result.await(15, TimeUnit.SECONDS));
            assertEquals("\"undefined\"", evaluated[0]);
        } finally { InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> holder[0].destroy()); }
    }
}
