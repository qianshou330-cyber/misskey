package com.bolubo.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class MainActivity extends ComponentActivity {
    private static final int CHOOSE_FILE = 8301;
    private static final int CAPTURE_IMAGE = 8302;
    private static final int MEDIA_PERMISSION = 8303;
    private static final int CAMERA_PERMISSION = 8304;
    private FrameLayout root;
    private WebView webView;
    private ProgressBar progress;
    private LinearLayout errorPanel;
    private TextView errorText;
    private PrivateDownloadBridge downloads;
    private ValueCallback<Uri[]> fileCallback;
    private ValueCallback<Uri[]> chooserResultCallback;
    private ValueCallback<Uri[]> cameraPermissionCallback;
    private boolean chooserActivityPending;
    private boolean cameraPermissionPending;
    private AlertDialog chooserDialog;
    private WebChromeClient.FileChooserParams chooserParams;
    private File cameraFile;
    private Uri cameraUri;
    private final List<File> completedCameraFiles = new ArrayList<>();
    private final List<Uri> completedCameraUris = new ArrayList<>();
    private PermissionRequest mediaRequest;
    private PermissionRequest mediaOsRequest;
    private boolean mediaPermissionPending;
    private String[] mediaResources;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private boolean failed;
    private boolean engineSupported;
    private String lastPage = OriginPolicy.HOME;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        File[] oldCaptures = new File(getCacheDir(), "camera").listFiles();
        if (oldCaptures != null) for (File file : oldCaptures) if (file.isFile() && file.getName().startsWith("capture-")) file.delete();
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 20, 17));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            Insets inset = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars()
                | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(inset.left, inset.top, inset.right, inset.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 20, 17));
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams progressLayout = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        root.addView(progress, progressLayout);
        buildErrorPanel();
        configureWebView();
        downloads = new PrivateDownloadBridge(this);
        PackageInfo provider = WebView.getCurrentWebViewPackage();
        engineSupported = provider != null && WebEnginePolicy.isSupported(provider.versionName) && downloads.install(webView);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { goBack(); }
        });
        if (!engineSupported) { showEngineRequired(); return; }
        if (state == null || webView.restoreState(state) == null || !OriginPolicy.isTrusted(webView.getUrl())) webView.loadUrl(OriginPolicy.HOME);
    }

    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(true);
        settings.setGeolocationEnabled(false);
        settings.setUserAgentString(settings.getUserAgentString() + " PUBOAndroid/1.0.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setDownloadListener((url, userAgent, disposition, mime, length) -> {
            if (OriginPolicy.canOpenExternally(url)) openExternal(url);
            else Toast.makeText(this, "请使用附件卡片上的保存按钮。", Toast.LENGTH_LONG).show();
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (!request.isForMainFrame()) return !url.startsWith("https://") && !url.startsWith("about:");
                if (OriginPolicy.isTrusted(url)) return false;
                if (request.hasGesture()) openExternal(url);
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (downloads != null) downloads.cancelForNavigation();
                revokePendingMedia();
                cancelFileChooser();
                cleanCompletedCameras();
                failed = false;
                errorPanel.setVisibility(View.GONE);
                if (!OriginPolicy.isTrusted(url)) { view.stopLoading(); showError("页面地址不可用。请返回 PUBO。"); return; }
                lastPage = url;
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showError("暂时无法连接 PUBO。请检查网络后重试。");
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) showError("网站暂时无法打开，请稍后重试。");
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                // This callback also covers avatars and remote embeds. Never bypass
                // TLS errors, but only a failed top-level request replaces the page.
                if (error.getUrl() != null && error.getUrl().equals(view.getUrl()))
                    showError("无法验证网站的安全连接，请稍后重试。");
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (downloads != null) downloads.cancelForNavigation();
                root.removeView(view);
                view.destroy();
                new AlertDialog.Builder(MainActivity.this).setTitle("网页组件已停止")
                    .setMessage("请重新打开 PUBO，或更新 Android System WebView 后再试。")
                    .setPositiveButton("重新打开", (dialog, which) -> recreate()).setCancelable(false).show();
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                if (value == 100 || failed) progress.setVisibility(View.GONE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams parameters) {
                // Result request codes are shared, so an older picker must return
                // before a new document can register a different callback.
                if (chooserActivityPending || cameraPermissionPending || mediaPermissionPending) { callback.onReceiveValue(null); return true; }
                cancelFileChooser();
                if (!OriginPolicy.isTrusted(view.getUrl())) { callback.onReceiveValue(null); return true; }
                fileCallback = callback;
                chooserParams = parameters;
                if (acceptsImages(parameters)) {
                    chooserDialog = new AlertDialog.Builder(MainActivity.this).setTitle("添加附件")
                        .setItems(new String[] { "选择文件", "拍摄照片" }, (dialog, which) -> {
                            if (fileCallback != callback) return;
                            if (which == 1) requestCamera(); else chooseFile();
                        })
                        .setOnCancelListener(dialog -> { if (fileCallback == callback) cancelFileChooser(); }).show();
                } else chooseFile();
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) { requestMedia(request); }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (mediaRequest == request) { mediaRequest = null; mediaResources = null; }
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
                fullScreenView = view;
                fullScreenCallback = callback;
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                webView.setVisibility(View.GONE);
                new WindowInsetsControllerCompat(getWindow(), root).hide(WindowInsetsCompat.Type.systemBars());
            }
            @Override public void onHideCustomView() { exitFullScreen(); }
            @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, Message result) {
                if (!userGesture) return false;
                // A disposable view intercepts target=_blank navigation. It has no JS
                // or native bridge; cookies are WebView-global and remain origin-scoped.
                WebView popup = new WebView(MainActivity.this);
                popup.getSettings().setJavaScriptEnabled(false);
                popup.getSettings().setAllowFileAccess(false);
                popup.getSettings().setAllowContentAccess(false);
                popup.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView child, WebResourceRequest request) {
                        String url = request.getUrl().toString();
                        if (OriginPolicy.isTrusted(url)) webView.loadUrl(url); else openExternal(url);
                        child.destroy();
                        return true;
                    }
                });
                ((WebView.WebViewTransport) result.obj).setWebView(popup);
                result.sendToTarget();
                return true;
            }
        });
    }

    private void buildErrorPanel() {
        errorPanel = new LinearLayout(this);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(28), dp(28), dp(28), dp(28));
        errorPanel.setBackgroundColor(Color.rgb(11, 20, 17));
        errorText = new TextView(this);
        errorText.setTextColor(Color.WHITE);
        errorText.setTextSize(18);
        errorText.setGravity(Gravity.CENTER);
        errorPanel.addView(errorText);
        Button retry = new Button(this);
        retry.setText("重新加载");
        retry.setOnClickListener(view -> { if (engineSupported) webView.loadUrl(lastPage); else recreate(); });
        errorPanel.addView(retry);
        Button home = new Button(this);
        home.setText("返回首页");
        home.setOnClickListener(view -> { if (engineSupported) webView.loadUrl(OriginPolicy.HOME); else showEngineRequired(); });
        errorPanel.addView(home);
        Button browser = new Button(this);
        browser.setText("浏览器打开");
        browser.setOnClickListener(view -> openExternal(OriginPolicy.HOME));
        errorPanel.addView(browser);
        root.addView(errorPanel, new FrameLayout.LayoutParams(-1, -1));
        errorPanel.setVisibility(View.GONE);
    }

    private void showError(String text) {
        failed = true;
        progress.setVisibility(View.GONE);
        errorText.setText(text);
        errorPanel.setVisibility(View.VISIBLE);
    }

    private void showEngineRequired() {
        showError("请先更新系统网页组件\n\nPUBO 需要 Android System WebView / Chrome 130 或以上版本。请在设备应用商店更新后重新打开，或使用新版浏览器访问。旧组件无法安全、完整地运行本站。");
    }

    private boolean acceptsImages(WebChromeClient.FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        if (types.length == 0) return true;
        for (String type : types) if (type.isEmpty() || "*/*".equals(type) || type.startsWith("image/")) return true;
        return false;
    }

    private void chooseFile() {
        if (fileCallback == null || chooserParams == null) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        List<String> types = new ArrayList<>();
        for (String type : chooserParams.getAcceptTypes()) if (type.matches("[A-Za-z0-9.+*-]+/[A-Za-z0-9.+*-]+")) types.add(type);
        if (types.size() == 1) intent.setType(types.get(0));
        else if (!types.isEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, chooserParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
        try {
            chooserActivityPending = true;
            chooserResultCallback = fileCallback;
            startActivityForResult(intent, CHOOSE_FILE);
        } catch (ActivityNotFoundException e) {
            chooserActivityPending = false;
            chooserResultCallback = null;
            cancelFileChooser();
            Toast.makeText(this, "设备没有可用的文件选择器。", Toast.LENGTH_LONG).show();
        }
    }

    private void requestCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermissionPending = true;
            cameraPermissionCallback = fileCallback;
            requestPermissions(new String[] {Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        } else captureImage();
    }

    private void captureImage() {
        if (fileCallback == null || !OriginPolicy.isTrusted(webView.getUrl())) { cancelFileChooser(); return; }
        try {
            File directory = new File(getCacheDir(), "camera");
            if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("camera");
            cameraFile = File.createTempFile("capture-", ".jpg", directory);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", cameraFile);
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camera.setClipData(ClipData.newRawUri("PUBO photo", cameraUri));
            chooserActivityPending = true;
            chooserResultCallback = fileCallback;
            startActivityForResult(camera, CAPTURE_IMAGE);
        } catch (IOException | ActivityNotFoundException e) {
            chooserActivityPending = false;
            chooserResultCallback = null;
            cancelFileChooser();
            Toast.makeText(this, "无法打开相机，请选择已有照片。", Toast.LENGTH_LONG).show();
        }
    }

    private void requestMedia(PermissionRequest request) {
        if (!OriginPolicy.isTrusted(request.getOrigin().toString()) || !OriginPolicy.isTrusted(webView.getUrl())
            || mediaRequest != null || mediaPermissionPending || cameraPermissionPending) { request.deny(); return; }
        List<String> resources = Arrays.asList(request.getResources());
        if (resources.isEmpty() || resources.stream().anyMatch(resource -> !PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && !PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource))) { request.deny(); return; }
        mediaRequest = request;
        mediaResources = request.getResources();
        new AlertDialog.Builder(this).setTitle("允许 PUBO 使用设备吗？")
            .setMessage(resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) ? "当前网页请求使用相机。若同时使用语音，也需要麦克风权限。" : "当前网页请求使用麦克风，用于录制语音。")
            .setPositiveButton("继续", (dialog, which) -> { if (mediaRequest == request) grantOrRequestMedia(); })
            .setNegativeButton("取消", (dialog, which) -> { if (mediaRequest == request) revokePendingMedia(); })
            .setOnCancelListener(dialog -> { if (mediaRequest == request) revokePendingMedia(); }).show();
    }

    private void grantOrRequestMedia() {
        if (mediaRequest == null) return;
        List<String> permissions = new ArrayList<>();
        for (String resource : mediaResources) {
            String permission = PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) ? Manifest.permission.RECORD_AUDIO : Manifest.permission.CAMERA;
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) permissions.add(permission);
        }
        if (!permissions.isEmpty()) {
            mediaOsRequest = mediaRequest;
            mediaPermissionPending = true;
            requestPermissions(permissions.toArray(new String[0]), MEDIA_PERMISSION);
        }
        else {
            if (OriginPolicy.isTrusted(webView.getUrl())) mediaRequest.grant(mediaResources); else mediaRequest.deny();
            mediaRequest = null;
            mediaResources = null;
        }
    }

    private void revokePendingMedia() {
        if (mediaRequest != null) mediaRequest.deny();
        mediaRequest = null;
        mediaOsRequest = null;
        mediaResources = null;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean granted = results.length > 0;
        for (int result : results) granted &= result == PackageManager.PERMISSION_GRANTED;
        if (requestCode == CAMERA_PERMISSION) {
            ValueCallback<Uri[]> expected = cameraPermissionCallback;
            cameraPermissionPending = false;
            cameraPermissionCallback = null;
            if (expected != null && fileCallback == expected) { if (granted) captureImage(); else cancelFileChooser(); }
        }
        if (requestCode == MEDIA_PERMISSION) {
            PermissionRequest expected = mediaOsRequest;
            mediaPermissionPending = false;
            mediaOsRequest = null;
            if (expected != null && expected == mediaRequest) { if (granted) grantOrRequestMedia(); else revokePendingMedia(); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PrivateDownloadBridge.CREATE_DOCUMENT) { downloads.onActivityResult(resultCode, data); return; }
        if (requestCode != CHOOSE_FILE && requestCode != CAPTURE_IMAGE) return;
        chooserActivityPending = false;
        ValueCallback<Uri[]> callback = fileCallback == chooserResultCallback ? fileCallback : null;
        chooserResultCallback = null;
        fileCallback = null;
        chooserParams = null;
        List<Uri> uris = new ArrayList<>();
        if (resultCode == RESULT_OK && OriginPolicy.isTrusted(webView.getUrl())) {
            if (requestCode == CAPTURE_IMAGE && cameraUri != null) uris.add(cameraUri);
            else if (data != null) {
                if (data.getData() != null) uris.add(data.getData());
                if (data.getClipData() != null) for (int index = 0; index < Math.min(data.getClipData().getItemCount(), 32); index++) uris.add(data.getClipData().getItemAt(index).getUri());
            }
        }
        uris.removeIf(uri -> uri == null || !"content".equals(uri.getScheme()));
        if (callback != null) callback.onReceiveValue(uris.isEmpty() ? null : uris.toArray(new Uri[0]));
        if (uris.isEmpty()) cleanCamera();
        else if (requestCode == CAPTURE_IMAGE && cameraFile != null) {
            completedCameraFiles.add(cameraFile);
            completedCameraUris.add(cameraUri);
            cameraFile = null;
            cameraUri = null;
        }
        // Camera content remains in this private cache while the webpage reads it.
    }

    private void cancelFileChooser() {
        if (chooserDialog != null) chooserDialog.dismiss();
        chooserDialog = null;
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = null;
        chooserParams = null;
        // Do not remove a successful photo until navigation/next chooser; the page may still upload it.
        cleanCamera();
    }

    private void cleanCamera() {
        if (cameraUri != null) revokeUriPermission(cameraUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (cameraFile != null) cameraFile.delete();
        cameraFile = null;
        cameraUri = null;
    }

    private void cleanCompletedCameras() {
        for (Uri uri : completedCameraUris) revokeUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        for (File file : completedCameraFiles) file.delete();
        completedCameraUris.clear();
        completedCameraFiles.clear();
    }

    private void openExternal(String url) {
        if (!OriginPolicy.canOpenExternally(url)) { Toast.makeText(this, "此链接无法在应用内打开。", Toast.LENGTH_SHORT).show(); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "设备没有可打开此链接的应用。", Toast.LENGTH_LONG).show(); }
    }

    private void exitFullScreen() {
        if (fullScreenView == null) return;
        root.removeView(fullScreenView);
        fullScreenView = null;
        webView.setVisibility(View.VISIBLE);
        if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden();
        fullScreenCallback = null;
        new WindowInsetsControllerCompat(getWindow(), root).show(WindowInsetsCompat.Type.systemBars());
    }

    private void goBack() {
        if (fullScreenView != null) exitFullScreen();
        else if (webView.canGoBack()) webView.goBack();
        else finish();
    }

    @Override protected void onSaveInstanceState(Bundle state) { webView.saveState(state); super.onSaveInstanceState(state); }
    @Override protected void onPause() { CookieManager.getInstance().flush(); webView.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
    @Override protected void onDestroy() {
        if (downloads != null) downloads.close();
        revokePendingMedia();
        cancelFileChooser();
        cleanCompletedCameras();
        exitFullScreen();
        root.removeView(webView);
        webView.destroy();
        super.onDestroy();
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
