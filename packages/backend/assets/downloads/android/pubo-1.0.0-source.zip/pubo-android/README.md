# PUBO Android

PUBO 整站 Android 测试版：`com.bolubo.app`，`1.0.0`（版本号 1），Android 8.0 / API 26 及以上，必须安装 Android System WebView / Chrome **130 或以上**（与当前网站构建目标一致）。旧组件会显示更新提示，不加载不兼容的网页。应用通过 Android System WebView 打开 `https://bolubo.com/`，需要网络；网站内容更新不需要重新发布 APK。图标沿用 PUBO 品牌资源。

## 构建

固定工具链：JDK 17、Gradle 8.13、Android Gradle Plugin 8.13.2、Android SDK 36、Build Tools 35.0.0。固定依赖见 `app/build.gradle`。设置 `JAVA_HOME` 与 `ANDROID_HOME` 后运行：

```powershell
.\gradlew.bat testDebugUnitTest lintRelease assembleDebug assembleDebugAndroidTest --no-daemon
.\gradlew.bat :app:packageRelease --no-daemon
```

第二条生成待签名的 `app/build/outputs/apk/release/app-release-unsigned.apk`，可由受限发布环境使用 `zipalign` 与 `apksigner` 签名，随后必须用 `apksigner verify --verbose --print-certs` 校验。未签名包不能直接发布。

也可以通过受限构建进程注入四个环境变量，再执行 `assembleRelease --no-daemon`：`PUBO_KEYSTORE_PATH`、`PUBO_KEYSTORE_PASSWORD`、`PUBO_KEY_ALIAS`、`PUBO_KEY_PASSWORD`。不得在源码、命令历史、共享日志或公开制品写入变量值；不要使用 `--debug` 或构建扫描。后续更新必须保留同一发布密钥，并增加 `versionCode`。

已连接测试设备时运行 `connectedDebugAndroidTest`。测试使用 `.debug` 包名，不覆盖正式安装。发布验证记录单独保存在本次发布制品目录。

## 网页与原生功能

- 浏览器标识附加 `PUBOAndroid/1.0.0`。正常账号密码、短信相关流程、动态验证码沿用网站；首版不接入通行密钥或原生后台推送。
- 只将 `https://bolubo.com` 及其默认 HTTPS 端口作为可信站点。外链由系统浏览器处理；不执行任意 `intent:`、`javascript:`、`file:`、`content:` 链接。拒绝证书错误和明文请求。
- 保留站点自己的登录存储与会话，禁用备份、第三方 Cookie 和发布版调试。不提取或记录 Cookie、令牌、私聊正文。
- 上传通过系统文件选择器；照片通过系统相机、临时私有缓存及 FileProvider；麦克风／相机仅在用户使用对应功能时请求。无需短信、联系人、通知或全盘存储权限。
- 返回、键盘避让、视频全屏、离线重试由原生壳补齐。无可用浏览器／相机／文件选择器时显示提示。

## 私聊附件协议

网页先通过原有受保护接口获取 Blob，再在**当前账号仍有效**且用户点击保存后发送。原生只接收字节，不接受 URL 或认证参数。

使用 `window.PuboNativeDownload.postMessage(JSON.stringify(message))`，监听此对象的 `onmessage`，解析 `event.data`。所有消息都有 `v: 1` 与唯一 `id`（字母、数字、`_`、`-`，1–80 字符）。

| 请求 `type` | 字段 | 响应 |
|---|---|---|
| `begin` | `name`, `mime`, `size` | 用户选择保存位置后 `ready` |
| `chunk` | 从 0 开始的 `seq`, `dataBase64` | `ack`，带同一 `seq` |
| `finish` | 无 | 实际保存完成后 `complete` |
| `cancel` | 无 | `cancelled` |

错误返回 `error` 与 `code`。一次只允许一个文件、一条未确认的分块；每块最多 65,536 字节，总大小最多 50 MiB。必须等 `ready` 才开始分块，每块必须等 `ack`。选择保存位置限时 120 秒，分块间隔限时 30 秒，总过程最多 10 分钟。取消、页面导航、账号切换时网页必须发送 `cancel` 并停止读取，释放会话锁；原生在完整页面导航、活动销毁和超时时再次清理。

原生采用 AndroidX WebKit 的精确来源白名单消息接口，并同时验证 `isMainFrame`、来源和当前顶层 URL；**不使用 `addJavascriptInterface`**。同源子框架也不能保存文件。旧 WebView 没有该安全接口时提示更新，不降级到不安全桥接。

字节先写入应用私有临时文件，收齐且校验长度后才写入用户选择的文档。正常取消／失败时尽力删除目标及临时内容；第三方文档提供器可以拒绝删除，进程被系统强制结束或存储介质移除时也可能残留不完整目标，不能宣称跨文档提供器原子保存。应用启动会清理私有传输残留。日志不含附件内容、文件名、保存位置或身份凭据。

## 验收边界

单元测试覆盖真实传输状态的大小、顺序、取消、文本安全处理和来源绕过；设备测试用实际 WebView 验证来源注入隔离和子框架拒绝。完整人工验收还应覆盖登录、账号切换、附件上传／下载、录音授权与拒绝、视频全屏、无网络和覆盖安装。模拟器通过不代表真实手机体验已通过。

工程独立于网站与 iOS，不包含服务器配置、签名秘密、站点会话或 YouTube 采集模块。
